document.addEventListener('DOMContentLoaded', () => {
  

    const toggles = document.querySelectorAll('.password-toggle');
    

    toggles.forEach(toggle => {
      
        toggle.innerHTML = ''; 
        toggle.style.cursor = 'pointer';
        toggle.style.fontSize = '1.2rem';
        toggle.style.opacity = '0.6';

        toggle.addEventListener('click', () => {

            const inputId = toggle.getAttribute('data-target');
            const inputField = document.getElementById(inputId);

            if (inputField.type === 'password') {
       
                inputField.type = 'text';
     
                toggle.innerHTML = ''; 
                toggle.style.opacity = '1.0';

            } else {
             
                inputField.type = 'password';
             
                toggle.innerHTML = '👁️';
                toggle.style.opacity = '0.6'; 
            }
        });
    });

    //Optional :((((
    /*
    const loginButton = document.querySelector('.login-btn');
    loginButton.addEventListener('click', (event) => {
        const accessCode = document.getElementById('accessCode').value;
        const adminKey = document.getElementById('adminKey').value;

  
        if (accessCode.trim() === '' || adminKey.trim() === '') {
            alert('Please enter both the Access Code and Admin Key.');
            event.preventDefault(); 
            return;
        }


    });*/
});