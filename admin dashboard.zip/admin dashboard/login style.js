const nominations = [
  { name: "Ariana Grande", section: "BSCS 3 - 1", color: "gray" },
  { name: "Sabrina Carpenter", section: "BSIT 3 - 1", color: "green" },
  { name: "Harry Styles", section: "BSIS 3 - 1", color: "blue" },
  { name: "Justin Bieber", section: "BSCS 3 - 1", color: "red" },
  { name: "Taylor Swift", section: "BSIT 3 - 1", color: "gray" }
];

const container = document.getElementById("cardContainer");

nominations.forEach(nominee => {
  const card = document.createElement("div");
  card.className = `card ${nominee.color}`;

  card.innerHTML = `
    <div class="card-left">
      <div class="avatar">👤</div>
      <div class="info">
        <h3>${nominee.name}</h3>
        <p>${nominee.section}</p>
        <div class="quote">"I have no tears left to cry"</div>
      </div>
    </div>
    <div class="actions">
      <button class="btn accept" onclick="handleAction('accept', '${nominee.name}')">Accept</button>
      <button class="btn reject" onclick="handleAction('reject', '${nominee.name}')">Reject</button>
    </div>
  `;

  container.appendChild(card);
});

function handleAction(action, name) {
  alert(`${name} was ${action}ed`);
}
