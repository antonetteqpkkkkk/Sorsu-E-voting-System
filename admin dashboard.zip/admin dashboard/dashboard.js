function makeAnnouncement() {
  alert("Open announcement form");
}

document.getElementById("totalVoters").textContent = 894;
document.getElementById("activeNow").textContent = 136;
